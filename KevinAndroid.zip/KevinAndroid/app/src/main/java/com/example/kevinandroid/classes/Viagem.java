package com.example.kevinandroid.classes;

public class Viagem {

    private String local;
    private String data;
    private int image;

    public Viagem(String local, String data, int image) {
        this.local = local;
        this.data = data;
        this.image = image;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
