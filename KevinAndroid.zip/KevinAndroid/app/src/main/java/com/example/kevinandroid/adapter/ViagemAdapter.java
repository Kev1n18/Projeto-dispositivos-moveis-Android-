package com.example.kevinandroid.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kevinandroid.R;
import com.example.kevinandroid.classes.Viagem;

import java.util.ArrayList;


public class ViagemAdapter extends BaseAdapter {
    Context context;
    ArrayList<Viagem> viagens;
    LayoutInflater inflter;

    public ViagemAdapter(Context applicationContext, ArrayList<Viagem> viagens) {
        this.context = context;
        this.viagens = viagens;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return viagens.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.activity_listview, null);
        TextView local = view.findViewById(R.id.textViewLocal);
        TextView data = view.findViewById(R.id.textViewData);
        ImageView icon = view.findViewById(R.id.icon);
        local.setText(viagens.get(i).getLocal());
        data.setText(viagens.get(i).getData());
        icon.setImageResource(viagens.get(i).getImage());
        return view;
    }
}