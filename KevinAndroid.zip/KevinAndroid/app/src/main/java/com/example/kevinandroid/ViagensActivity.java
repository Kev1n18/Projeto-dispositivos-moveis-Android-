package com.example.kevinandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kevinandroid.classes.Viagem;
import com.example.kevinandroid.adapter.ViagemAdapter;

import java.util.ArrayList;

public class ViagensActivity extends AppCompatActivity {

    private EditText local, data;
    private Button inserir;
    private ListView listaViagens;
    private ViagemAdapter viagemAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inserir_viagem);

        local = findViewById(R.id.rform1);
        data = findViewById(R.id.rform2);
        inserir = findViewById(R.id.inserir);
        listaViagens = findViewById(R.id.listaViagens);

        ArrayList<Viagem> minhasViagens = new ArrayList<Viagem>();
        ViagemAdapter viagemAdapter = new ViagemAdapter(getApplicationContext(), minhasViagens);

        inserir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Viagem viagem = new Viagem(local.getText().toString(), data.getText().toString(), R.drawable.img);
                minhasViagens.add(viagem);
                viagemAdapter.notifyDataSetChanged();
            }
        });

        listaViagens.setAdapter(viagemAdapter);

        listaViagens.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                Intent intent = new Intent(ViagensActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });
    }
}