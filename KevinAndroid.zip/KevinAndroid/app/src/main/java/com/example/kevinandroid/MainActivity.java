package com.example.kevinandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button utilizador, lista_viagens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        utilizador = findViewById(R.id.bUtilizador);
        lista_viagens = findViewById(R.id.bLista);

        utilizador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, UtilizadorActivity.class);
                MainActivity.this.startActivity(myIntent);
            }
        });

        lista_viagens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, ViagensActivity.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
    }
}